<h1>trading Dashboard</h1><br/>
<img src="https://github.com/edjanga/tradingdash/actions/workflows/tests.yml/badge.svg">
<br/>
Repository containing the source code of my web app.<br/>
<b>Link to Web App</b>: <a href="https://tradingdash.herokuapp.com">Web App</a><br/>
