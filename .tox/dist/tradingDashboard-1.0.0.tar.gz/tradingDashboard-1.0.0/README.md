<h1>trading Dashboard</h1><br/>
Repositary containing the source code of my web app.<br/>

