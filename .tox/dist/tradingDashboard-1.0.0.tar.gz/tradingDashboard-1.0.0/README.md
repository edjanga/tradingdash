<h1>trading Dashboard</h1><br/>
<img src="https://github.com/edjanga/tradingdash/actions/workflows/tests.yml/badge.svg">
<br/>
Repository containing the source code of my web app.<br/>

