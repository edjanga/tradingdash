from src.tradingDashboard.Backtest import Table, Performance
#from src.tradingDashboard.config import TiingoConfig
from src.tradingDashboard.data import Data
from src.tradingDashboard.logger import Logs
from src.tradingDashboard.Strategies import BuyAndHold,TacticalAllocation,PortfolioStrategies