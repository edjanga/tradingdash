import pandas as pd
import numpy as np
import concurrent.futures
from src.tradingDashboard.data import Data
from pandas.tseries.offsets import BDay
from src.tradingDashboard.Strategies3 import TacticalAllocation
import inspect
from scipy.stats import skew,kurtosis
import pdb
import matplotlib.pyplot as plt

data_obj = Data()

class Performance:

    """
        Backtester environment allowing one to compute performance metrics for a given dataframe
        where:
            -columns: strategies
            -row: date
            -data: returns
    """
    @staticmethod
    def returns(df):
        t = (df.index[-1] - df.index[0]).days / 365.25
        return (df+1).apply(lambda x,t: (x[-1] / x[0]) ** (1 /t) - 1,args=[t])

    @staticmethod
    def vol(df):
        if isinstance(df,pd.DataFrame):
            return pd.DataFrame(df.std())
        if isinstance(df,pd.Series):
            return df.std()

    @staticmethod
    def returns_adjusted(df):
        query = data_obj.write_query_symbol(symbol=['BIL'])
        rf_df = data_obj.query(query,set_index=True).apply(lambda x: np.log(x/x.shift())).dropna()
        rf_df.index.name = 'time'
        if isinstance(df,pd.DataFrame):
            df_copy = df.iloc[1:,:].subtract(rf_df.values, 1)
        if isinstance(df,pd.Series):
            df_copy = df[1:] - rf_df.BIL
        return df_copy

    # @staticmethod
    # def sharpe(df):
    #     if isinstance(df,pd.DataFrame):
    #         df_copy = Performance.returns_adjusted(df)
    #         return pd.DataFrame(pd.DataFrame(df_copy.mean()/df_copy.std()))
    #     if isinstance(df,pd.Series):
    #         df_copy = Performance.returns_adjusted(df)
    #         return df_copy.mean()/df_copy.std()

    @staticmethod
    def cvar(df):
        cvar_ls = list(map(lambda x: x[x<=np.quantile(x,.05)].mean(), df.transpose().values))
        return pd.DataFrame(cvar_ls,index=df.columns)

    @staticmethod
    def maxdrawdown(df):
        if isinstance(df,pd.Series):
            df_copy = pd.DataFrame(df+1)
            df_copy = df_copy.div(df_copy.cummax()) - 1
            max_drawdown_s = df_copy.cummin().min()
            return max_drawdown_s
        if isinstance(df,pd.DataFrame):
            df_copy = df+1
            df_copy = df_copy.div(df_copy.cummax()) - 1
            max_drawdown_s = df_copy.cummin().min()
            return pd.DataFrame(max_drawdown_s)

    @staticmethod
    def skew(df):
        skew_ls = list(map(lambda x: skew(x),df.transpose().values))
        return pd.DataFrame(skew_ls,index=df.columns)

    @staticmethod
    def kurtosis(df):
        kurtosis_ls = list(map(lambda x: kurtosis(x), df.transpose().values))
        return pd.DataFrame(kurtosis_ls,index=df.columns)

    # @staticmethod
    # def rolling_maxdrawdown(df,rolling_period=12):
    #     return np.sqrt(rolling_period)*df.rolling(rolling_period).apply(Performance.maxdrawdown).dropna()
    #
    # @staticmethod
    # def rolling_sharpe(df,rolling_period=12):
    #     df_copy = Performance.returns_adjusted(df)
    #     rolling_obj = df_copy.rolling(rolling_period)
    #     df_copy = (rolling_obj.mean()).div(rolling_obj.std()).dropna()
    #     return np.sqrt(rolling_period)*df_copy
    #
    # @staticmethod
    # def rolling_vol(df,rolling_period=12):
    #     return np.sqrt(rolling_period)*df.rolling(rolling_period).std().dropna()


class Table(Performance):

    def __init__(self,df):
        self.df = df
        methods_ls = inspect.getmembers(Performance,predicate=inspect.isfunction)
        self.metric_name = [method[-1] for method in methods_ls if ('rolling' not in method[0])&('adjusted' not in method[0])]
        self.rolling_name = [method[-1] for method in methods_ls if ('rolling' in method[0])&('adjusted' not in method[0])]

    def table_aggregate(self):

        aggregate_perf_dd = dict()

        def add_performance_metrics(metric,df):
            aggregate_perf_dd[metric.__name__] = metric(df)
            return aggregate_perf_dd

        with concurrent.futures.ThreadPoolExecutor() as executor:
            results = []
            for metric in self.metric_name:
                results.append(executor.submit(add_performance_metrics,metric,self.df))
        aggregate_perf_df = pd.concat(aggregate_perf_dd, axis=1).droplevel(1, 1).round(4)
        return aggregate_perf_df

    def rolling_aggregate(self):

        aggregate_roll_dd = dict()

        def add_rolling_metrics(rolling_metric,df):
            aggregate_roll_dd[rolling_metric.__name__] = rolling_metric(df)

            return aggregate_roll_dd

        with concurrent.futures.ThreadPoolExecutor() as executor:
            results = []
            for metric in self.rolling_name:
                results.append(executor.submit(add_rolling_metrics,metric,self.df))
        return aggregate_roll_dd


if __name__ == '__main__':
    #allocation = 'tactical_asset_allocation'
    #data_obj = Data()
    perf_obj = Performance()
    #query = data_obj.write_query_returns(allocation)
    #df = data_obj.query(query,set_index=True)
    #df.index.name = 'time'

    #perf_obj.rolling_sharpe(df)
    #table_obj = Table(df)
    #table_obj.returns(df)
    #aggregate_perf_df = table_obj.table_aggregate()
    #pdb.set_trace()
    #print(aggregate_perf_df.head())
    data_obj = Data()
    query = data_obj.write_query_symbol(symbol=['VTI','VEU','VNQ','AGG','DBC'])
    df = data_obj.query(query,set_index=True)
    #allocation = TacticalAllocation()
    #equity_curve_df = allocation.ivy(df)
    #t = (equity_curve_df.index[-1] - equity_curve_df.index[0]).days / 252
    #ret = (equity_curve_df.iloc[-1] / equity_curve_df.iloc[0]) ** (1 /t) - 1
    #risk = (equity_curve_df+1).std()
    #pdb.set_trace()
    df_resampled_df = df.resample('BM').last()
    df_resampled_ma_10_df = (df_resampled_df>df_resampled_df.rolling(10).mean()).astype(int)
    quantity = pd.DataFrame(index=df_resampled_df.index,columns=df_resampled_df.columns)
    startDate = df_resampled_df.apply(lambda x:x.first_valid_index()).sort_values()[-2]
    quantity.loc[:startDate,:] = 0
    for date, series_s in df_resampled_df.loc[startDate:,:].iterrows():
        target_weight = pd.Series(np.where(series_s.isnull(), False, True),index=series_s.index).astype(int)
        target_weight = target_weight*pd.Series(data=.2,index=target_weight.index)#*df_resampled_ma_10_df.loc[date,:]
        if date == startDate:
            quantity.loc[date] = target_weight/series_s
        else:
            portfolio_value = (quantity.shift().loc[date,:]*series_s).sum()
            quantity.loc[date] = portfolio_value*target_weight/series_s
    quantity = quantity.resample('B').first()
    quantity = pd.concat([df.loc[df.index<quantity.index[0],:],quantity],axis=0)
    quantity = quantity.ffill().bfill()
    quantity = quantity.loc[df.index,:]
    equity_curve_df = quantity.mul(df).sum(axis=1).replace(0,1)
    pdb.set_trace()
    equity_curve_df.plot()
    plt.show()
    #pdb.set_trace()
    # for date,series_s in df.iterrows():
    #     target_weight = pd.Series(np.where(series_s.isnull(),False,True),index=series_s.index).astype(int)
    #     #price = pd.Series(np.where(series_s.isnull(),0,series_s),index=series_s.index)
    #     if (date.month+1)==(date+BDay(1)).month:
    #         if start:
    #             quantity.loc[date,:] = initial_investment*target_weight/series_s
    #             start = False
    #         else:
    #             try:
    #                 portfolio_value = quantity.loc[quantity.index[idx-1], :]*target_weight/series_s
    #                 quantity.loc[date, :] = portfolio_value*target_weight/series_s
    #             except ZeroDivisionError:
    #                 pdb.set_trace()
    #     else:
    #         if idx > 0:
    #             quantity.loc[date, :] = quantity.loc[quantity.index[idx-1], :]
    #     idx += 1
    # pdb.set_trace()


    # for i in range(price.shape[0]):
    #     if i == 0:
    #         quantity[i] = initial_investment * target_weight / price[i]
    #         pdb.set_trace()
    #     else:
    #         portfolio_value = (quantity[i - 1] * price[i]).sum()
    #         quantity[i] = portfolio_value * target_weight / price[i]
    # pdb.set_trace()
    # # Final assembly
    # columns = pd.MultiIndex.from_product([["price", "quantity"], list("wxyz")])
    # df = pd.DataFrame(np.hstack([price, quantity]), columns=columns)